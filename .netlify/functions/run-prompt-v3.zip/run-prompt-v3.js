// netlify/functions/run-prompt-v3.js
// Full data fetch + Gemini report generation
const https = require('https');

const CONFIG = {
  client_id: process.env.GADS_CLIENT_ID || '',
  client_secret: process.env.GADS_CLIENT_SECRET || '',
  refresh_token: process.env.GADS_REFRESH_TOKEN || '',
  developer_token: process.env.GADS_DEV_TOKEN || '',
  mcc_id: '9060186325',
  llm_api_url: process.env.LLM_API_URL || 'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent',
  llm_api_key: process.env.LLM_API_KEY || '',
};

function httpsPost(url, opts, body) {
  return new Promise((resolve) => {
    const req = https.request(url, opts, (res) => {
      let d = '';
      res.on('data', c => d += c);
      res.on('end', () => {
        try { resolve({ status: res.statusCode, data: JSON.parse(d) }); }
        catch { resolve({ status: res.statusCode, raw: d.substring(0, 500), error: true }); }
      });
    });
    req.on('error', (e) => resolve({ status: 0, error: e.message }));
    req.setTimeout(30000, () => { req.destroy(); resolve({ status: 0, error: 'timeout' }); });
    if (body) req.write(body);
    req.end();
  });
}

async function getAccessToken() {
  const body = new URLSearchParams({
    client_id: CONFIG.client_id,
    client_secret: CONFIG.client_secret,
    refresh_token: CONFIG.refresh_token,
    grant_type: 'refresh_token',
  }).toString();
  const res = await httpsPost('https://oauth2.googleapis.com/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
  }, body);
  if (res.data?.access_token) return res.data.access_token;
  throw new Error('Token fail: ' + (res.raw || res.error));
}

function gadsSearch(accountId, token, query) {
  const body = JSON.stringify({ query });
  return new Promise((resolve) => {
    const req = https.request(
      `https://googleads.googleapis.com/v23/customers/${accountId}/googleAds:search`,
      {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'developer-token': CONFIG.developer_token,
          'login-customer-id': CONFIG.mcc_id,
          'Content-Type': 'application/json',
        },
      },
      (res) => {
        let d = '';
        res.on('data', c => d += c);
        res.on('end', () => {
          try {
            const parsed = JSON.parse(d);
            resolve(parsed.results || []);
          } catch {
            console.log('GADS search error:', res.statusCode, d.substring(0, 300));
            resolve([]);
          }
        });
      }
    );
    req.on('error', (e) => { console.log('GADS req error:', e.message); resolve([]); });
    req.setTimeout(30000, () => { req.destroy(); resolve([]); });
    req.end(body);
  });
}

async function fetchAll(accountId, token, days) {
  const D = `LAST_${days}_DAYS`;
  const queries = [
    // 1. Campaigns
        `SELECT campaign.resource_name, campaign.name, campaign.status, campaign.advertising_channel_type, campaign.bidding_strategy_type, campaign.target_roas, metrics.impressions, metrics.clicks, metrics.conversions, metrics.conversions_value, metrics.cost_micros, metrics.ctr FROM campaign WHERE segments.date DURING ${D}`,
    // 2. Conversion actions
    `SELECT conversion_action.resource_name, conversion_action.name, conversion_action.type, conversion_action.conversion_action_status, conversion_action.attribution_model_type, conversion_action.counting_type FROM conversion_action`,
    // 3. Device performance
    `SELECT segments.device, metrics.impressions, metrics.clicks, metrics.conversions, metrics.conversions_value, metrics.cost_micros, metrics.ctr FROM campaign WHERE segments.date DURING ${D}`,
    // 4. Network performance
    `SELECT segments.advertising_channel_type, metrics.impressions, metrics.clicks, metrics.conversions, metrics.conversions_value, metrics.cost_micros, metrics.ctr FROM campaign WHERE segments.date DURING ${D}`,
    // 5. Asset groups
    `SELECT asset_group.resource_name, asset_group.name, asset_group.status, asset_group.ad_strength, asset_group.primary_status, metrics.impressions, metrics.clicks, metrics.conversions, metrics.conversions_value, metrics.cost_micros FROM asset_group_view WHERE segments.date DURING ${D}`,
    // 6. Negative keywords
    `SELECT campaign_negative.keyword.text, campaign_negative.keyword.match_type FROM campaign_negative`,
  ];

  const results = await Promise.allSettled(queries.map(q => gadsSearch(accountId, token, q)));
  return {
    campaigns: results[0].status === 'fulfilled' ? results[0].value : [],
    conversions: results[1].status === 'fulfilled' ? results[1].value : [],
    device: results[2].status === 'fulfilled' ? results[2].value : [],
    network: results[3].status === 'fulfilled' ? results[3].value : [],
    assets: results[4].status === 'fulfilled' ? results[4].value : [],
    negatives: results[5].status === 'fulfilled' ? results[5].value : [],
  };
}

function formatData(data) {
  let o = '';

  // Account totals
  let totalSpend = 0, totalConv = 0, totalRev = 0, totalClicks = 0, totalImps = 0;
  for (const c of data.campaigns) {
    const m = c.metrics || {};
    totalSpend += parseInt(m.costMicros || 0) / 1e6;
    totalConv += parseFloat(m.conversions || 0);
    totalRev += parseFloat(m.conversionsValue || 0);
    totalClicks += parseInt(m.clicks || 0);
    totalImps += parseInt(m.impressions || 0);
  }

  o = `ACCOUNT TOTALS:\nSpend: $${totalSpend.toFixed(2)} | Clicks: ${totalClicks} | Impressions: ${totalImps} | CTR: ${totalImps > 0 ? (totalClicks/totalImps*100).toFixed(2) : 0}% | Conversions: ${totalConv} | Revenue: $${totalRev.toFixed(2)} | ROAS: ${totalSpend > 0 ? (totalRev/totalSpend).toFixed(2) : 0}x | CPA: ${totalConv > 0 ? (totalSpend/totalConv).toFixed(2) : 0}\n\n`;

  // Campaigns
  o += `CAMPAIGNS (${data.campaigns.length}):\n`;
  for (const c of data.campaigns) {
    const cm = c.campaign || {};
    const m = c.metrics || {};
    const spend = parseInt(m.costMicros || 0) / 1e6;
    const rev = parseFloat(m.conversionsValue || 0);
    const convs = parseFloat(m.conversions || 0);
    const roas = spend > 0 ? (rev / spend) : 0;
    const cpa = convs > 0 ? (spend / convs) : 0;
    o += `${cm.name || '?'} [${cm.status || '?'}]\n`;
    o += `  Type: ${cm.advertisingChannelType || cm.advertisingChannelSubType || '?'} | Bidding: ${cm.biddingStrategyType || '?'}\n`;
    o += `  Spend: $${spend.toFixed(2)} | Clicks: ${parseInt(m.clicks||0)} | Imps: ${parseInt(m.impressions||0)} | CTR: ${parseFloat(m.ctr||0)>0?(parseFloat(m.ctr)*100).toFixed(2)+'%':'?'} | Convs: ${convs} | Rev: $${rev.toFixed(2)} | ROAS: ${roas.toFixed(2)}x | CPA: $${cpa.toFixed(2)}\n`;
    if (cm.targetRoas) o += `  Target ROAS: ${(cm.targetRoas/1000).toFixed(1)}x\n`;
  }

  // Conversions
  o += `\nCONVERSION ACTIONS (${data.conversions.length}):\n`;
  for (const c of data.conversions) {
    const ca = c.conversionAction || {};
    o += `${ca.name || '?'} | Type: ${ca.type || '?'} | Status: ${ca.conversionActionStatus || '?'} | Attribution: ${ca.attributionModelType || '?'} | Counting: ${ca.countingType || '?'}\n`;
  }

  // Device
  o += `\nDEVICE PERFORMANCE:\n`;
  for (const v of data.device) {
    const m = v.metrics || {};
    const spend = parseInt(m.costMicros || 0) / 1e6;
    const rev = parseFloat(m.conversionsValue || 0);
    o += `${v.segments?.device || '?'}: Spend $${spend.toFixed(2)} | Clicks ${parseInt(m.clicks||0)} | Convs ${parseFloat(m.conversions||0)} | ROAS ${spend>0?(rev/spend).toFixed(2)+'x':'?'} | CVR ${parseInt(m.clicks||0)>0?(parseFloat(m.conversions||0)/parseInt(m.clicks||0)*100).toFixed(2)+'%':'?'}\n`;
  }

  // Network
  o += `\nNETWORK:\n`;
  for (const n of data.network) {
    const m = n.metrics || {};
    o += `${n.segments?.advertisingChannelType || '?'}: Spend $${(parseInt(m.costMicros||0)/1e6).toFixed(2)} | Clicks ${parseInt(m.clicks||0)} | CTR ${parseFloat(m.ctr||0)>0?(parseFloat(m.ctr)*100).toFixed(2)+'%':'?'} | Convs ${parseFloat(m.conversions||0)}\n`;
  }

  // Assets
  o += `\nASSET GROUPS (${data.assets.length}):\n`;
  for (const a of data.assets) {
    const ag = a.assetGroup || {};
    const m = a.metrics || {};
    o += `${ag.name || '?'} | Strength: ${ag.adStrength || '?'} | Status: ${ag.status || '?'} | Spend: $${(parseInt(m.costMicros||0)/1e6).toFixed(2)} | Convs: ${parseFloat(m.conversions||0)} | Rev: $${parseFloat(m.conversionsValue||0).toFixed(2)}\n`;
  }

  // Negatives
  o += `\nNEGATIVE KEYWORDS (${data.negatives.length}):\n`;
  const byType = {};
  for (const n of data.negatives) {
    const mt = n.campaignNegative?.keyword?.matchType || '?';
    byType[mt] = (byType[mt] || 0) + 1;
  }
  o += `By type: ${JSON.stringify(byType)}\n`;
  for (const n of data.negatives.slice(0, 40)) {
    o += `${n.campaignNegative?.keyword?.text || '?'} (${n.campaignNegative?.keyword?.matchType || '?'})\n`;
  }

  return o;
}

async function callLLM(prompt, accountName, accountId, dateRange, fmtData, channel, category) {
  if (!CONFIG.llm_api_key) return null;

  const cleanCat = category.replace(/[^\w\s]/g, '').trim();
  const expertise = {
    'Ad Copy': 'ad copy and creative strategy',
    'Analysis': 'performance analysis and optimization',
    'Audits': 'comprehensive account audits',
    'Tracking': 'conversion tracking and attribution',
    'PMax': 'Performance Max campaigns',
    'Optimise': 'campaign optimization',
    'Feed Management': 'product feed management',
    'CRM Integration': 'CRM integration and offline conversions',
    'Reporting': 'performance reporting',
    'Staff Dashboards': 'team performance dashboards',
  };
  const domain = expertise[cleanCat] || expertise['Analysis'];

  const sys = `You are an advanced digital marketing expert specializing in ${domain}.

Follow these rules:
- Be SPECIFIC with exact numbers from the data
- Cross-reference findings across campaigns
- Calculate derived metrics: ROAS, CPA, CTR, CVR, efficiency
- Flag anomalies: duplicate tracking, budget issues, underperforming segments
- Every recommendation states WHAT to do, WHERE, and WHY
- Use tables for comparisons
- Professional, direct tone - no fluff
- Prioritize recommendations: 🔴 High / 🟡 Medium / 🟢 Low
- End with top 3-4 actions that would most impact performance`;

  const usr = (prompt || 'Comprehensive ' + (category||'performance') + ' analysis') + `

Account: ${accountName} (${accountId})
Channel: ${channel}
Category: ${category}
Date range: ${dateRange}

ACCOUNT DATA:
${fmtData}`;

  const body = JSON.stringify({
    systemInstruction: { role: 'user', parts: [{ text: sys }] },
    contents: [{ role: 'user', parts: [{ text: usr }] }],
    generationConfig: { temperature: 0.1, maxOutputTokens: 16000 }
  });

  const url = `${CONFIG.llm_api_url}?key=${CONFIG.llm_api_key}`;
  const res = await httpsPost(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
  }, body);

  if (res.error || res.status !== 200) return null;
  return res.data?.candidates?.[0]?.content?.parts?.[0]?.text;
}

function basicReport(name, id, dr, data) {
  let r = `# Report: ${name}\n\n**Account:** ${id} | **Period:** ${dr}\n\n`;
  r += `## Campaigns\n\n| Campaign | Type | Status | Spend | Clicks | Convs | ROAS |\n|----------|------|--------|-------|--------|-------|------|\n`;
  for (const c of data.campaigns || []) {
    const cm = c.campaign || {}; const m = c.metrics || {};
    const sp = parseInt(m.costMicros||0)/1e6; const rv = parseFloat(m.conversionsValue||0);
    r += `| ${cm.name||'?'} | ${cm.campaignType||'?'} | ${cm.status||'?'} | $${sp.toFixed(2)} | ${parseInt(m.clicks||0)} | ${parseFloat(m.conversions||0)} | ${(sp>0?(rv/sp).toFixed(2):'0')}x |\n`;
  }
  r += `\n*Generated: ${new Date().toISOString().split('T')[0]}*\n`;
  return r;
}

exports.handler = async (event) => {
  const hdrs = { 'Access-Control-Allow-Origin': '*', 'Content-Type': 'application/json', 'Access-Control-Allow-Headers': 'Content-Type' };
  if (event.httpMethod !== 'POST') return { statusCode: 405, headers: hdrs, body: JSON.stringify({ error: 'Method not allowed' }) };

  try {
    const { prompt, promptName, account, accountId, dateRange, days, channel, category } = JSON.parse(event.body || '{}');
    if (!accountId) return { statusCode: 400, headers: hdrs, body: JSON.stringify({ error: 'Missing accountId' }) };

    const d = parseInt(days) || 7;
    console.log('run-prompt-v3: accountId=' + accountId + ' days=' + d);

    const token = await getAccessToken();
    const data = await fetchAll(accountId, token, d);

    console.log('Fetched: campaigns=' + data.campaigns.length + ' conversions=' + data.conversions.length);

    const fmt = formatData(data);
    let report = await callLLM(prompt, account, accountId, dateRange, fmt, channel || 'Google Ads', category || '');

    if (!report) report = basicReport(account, accountId, dateRange, data);

    return {
      statusCode: 200,
      headers: hdrs,
      body: JSON.stringify({
        ok: true,
        prompt: promptName,
        account, accountId, dateRange,
        report,
        dataPoints: {
          campaigns: data.campaigns.length,
          conversions: data.conversions.length,
          assets: data.assets.length,
          negatives: data.negatives.length,
        },
        generated: new Date().toISOString(),
      }),
    };
  } catch (err) {
    console.error('Error:', err.message);
    return { statusCode: 500, headers: hdrs, body: JSON.stringify({ error: 'Failed', detail: err.message }) };
  }
};