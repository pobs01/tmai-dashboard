// netlify/functions/debug-api.js
// Test Google Ads API directly and return raw results
const https = require('https');

function httpsRequest(url, options, body) {
  return new Promise((resolve) => {
    const req = https.request(url, options, (res) => {
      let data = '';
      res.on('data', c => data += c);
      res.on('end', () => resolve({ status: res.statusCode, body: data.substring(0, 3000) }));
    });
    req.on('error', (e) => resolve({ status: 0, error: e.message }));
    if (body) req.write(body);
    req.end();
  });
}

exports.handler = async () => {
  const clientId = process.env.GADS_CLIENT_ID;
  const clientSecret = process.env.GADS_CLIENT_SECRET;
  const refreshToken = process.env.GADS_REFRESH_TOKEN;
  const devToken = process.env.GADS_DEV_TOKEN;

  // Get token
  const tokenData = await httpsRequest('https://oauth2.googleapis.com/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
  }, new URLSearchParams({
    client_id: clientId,
    client_secret: clientSecret,
    refresh_token: refreshToken,
    grant_type: 'refresh_token',
  }).toString());

  const token = JSON.parse(tokenData.body).access_token;

  // Query campaigns
  const query = 'SELECT campaign.name, metrics.clicks FROM campaign WHERE segments.date DURING LAST_7_DAYS LIMIT 5';
  const result = await httpsRequest(
    'https://googleads.googleapis.com/v23/customers/6457701262/googleAds:search',
    {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${token}`,
        'developer-token': devToken,
        'login-customer-id': '9060186325',
        'Content-Type': 'application/json',
      },
    },
    JSON.stringify({ query })
  );

  return {
    statusCode: 200,
    headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
    body: JSON.stringify({
      tokenOk: !!token,
      clientId: clientId ? clientId.substring(0, 15) + '...' : 'MISSING',
      queryResult: {
        status: result.status,
        body: result.body
      }
    })
  };
};