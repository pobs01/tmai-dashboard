// Check env vars
exports.handler = async () => {
  return {
    statusCode: 200,
    headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' },
    body: JSON.stringify({
      GADS_CLIENT_ID: process.env.GADS_CLIENT_ID ? 'SET (' + process.env.GADS_CLIENT_ID.substring(0,10) + '...)' : 'MISSING',
      GADS_CLIENT_SECRET: process.env.GADS_CLIENT_SECRET ? 'SET (' + process.env.GADS_CLIENT_SECRET.substring(0,5) + '...)' : 'MISSING',
      GADS_REFRESH_TOKEN: process.env.GADS_REFRESH_TOKEN ? 'SET (' + process.env.GADS_REFRESH_TOKEN.substring(0,5) + '...)' : 'MISSING',
      GADS_DEV_TOKEN: process.env.GADS_DEV_TOKEN ? 'SET (' + process.env.GADS_DEV_TOKEN.substring(0,5) + '...)' : 'MISSING',
      LLM_API_KEY: process.env.LLM_API_KEY ? 'SET (' + process.env.LLM_API_KEY.substring(0,5) + '...)' : 'MISSING',
      NODE_ENV: process.env.NODE_ENV,
    })
  };
};