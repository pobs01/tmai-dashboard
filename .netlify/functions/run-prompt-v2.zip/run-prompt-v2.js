// netlify/functions/run-prompt-v2.js
// v2 - Force redeploy, bypass cache
const https = require('https');

const CONFIG = {
  client_id: process.env.GADS_CLIENT_ID || '',
  client_secret: process.env.GADS_CLIENT_SECRET || '',
  refresh_token: process.env.GADS_REFRESH_TOKEN || '',
  developer_token: process.env.GADS_DEV_TOKEN || '',
  mcc_id: '9060186325',
  llm_api_url: process.env.LLM_API_URL || 'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent',
  llm_api_key: process.env.LLM_API_KEY || '',
};

function httpsPost(url, opts, body) {
  return new Promise((resolve) => {
    const req = https.request(url, opts, (res) => {
      let d = '';
      res.on('data', c => d += c);
      res.on('end', () => {
        try { resolve({ status: res.statusCode, data: JSON.parse(d) }); }
        catch { resolve({ status: res.statusCode, raw: d.substring(0, 300), error: true }); }
      });
    });
    req.on('error', (e) => resolve({ status: 0, error: e.message }));
    req.setTimeout(30000, () => { req.destroy(); resolve({ status: 0, error: 'timeout' }); });
    if (body) req.write(body);
    req.end();
  });
}

async function getAccessToken() {
  const body = new URLSearchParams({
    client_id: CONFIG.client_id,
    client_secret: CONFIG.client_secret,
    refresh_token: CONFIG.refresh_token,
    grant_type: 'refresh_token',
  }).toString();

  const res = await httpsPost('https://oauth2.googleapis.com/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
  }, body);

  if (res.data?.access_token) return res.data.access_token;
  throw new Error('Token fail: ' + JSON.stringify(res));
}

function gadsSearch(accountId, token, query) {
  const body = JSON.stringify({ query });
  return new Promise((resolve) => {
    const req = https.request(
      `https://googleads.googleapis.com/v23/customers/${accountId}/googleAds:search`,
      {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'developer-token': CONFIG.developer_token,
          'login-customer-id': CONFIG.mcc_id,
          'Content-Type': 'application/json',
        },
      },
      (res) => {
        let d = '';
        res.on('data', c => d += c);
        res.on('end', () => {
          try { resolve(JSON.parse(d).results || []); } catch { resolve([]); }
        });
      }
    );
    req.on('error', () => resolve([]));
    req.setTimeout(30000, () => { req.destroy(); resolve([]); });
    req.end(body);
  });
}

async function fetchData(accountId, token, days) {
  const queries = [
    `SELECT metrics.impressions, metrics.clicks, metrics.conversions, metrics.conversions_value, metrics.cost_micros FROM campaign WHERE segments.date DURING LAST_${days}_DAYS`,
    `SELECT campaign.resource_name, campaign.name, campaign.status, campaign.advertising_channel_type, campaign.campaign_type, campaign.bidding_strategy_type, campaign.target_roas, campaign.daily_budget_micros, metrics.impressions, metrics.clicks, metrics.conversions, metrics.conversions_value, metrics.cost_micros, metrics.ctr FROM campaign WHERE segments.date DURING LAST_${days}_DAYS`,
    `SELECT conversion_action.name, conversion_action.type, conversion_action.conversion_action_status, conversion_action.attribution_model_type, conversion_action.counting_type FROM conversion_action`,
    `SELECT segments.device, metrics.impressions, metrics.clicks, metrics.conversions, metrics.conversions_value, metrics.cost_micros, metrics.ctr FROM campaign WHERE segments.date DURING LAST_${days}_DAYS`,
    `SELECT asset_group.name, asset_group.ad_strength, asset_group.status, metrics.impressions, metrics.clicks, metrics.conversions, metrics.conversions_value, metrics.cost_micros FROM asset_group_view WHERE segments.date DURING LAST_${days}_DAYS`,
    `SELECT campaign_negative.keyword.text, campaign_negative.keyword.match_type FROM campaign_negative`,
  ];

  const results = await Promise.allSettled(queries.map(q => gadsSearch(accountId, token, q)));
  return {
    overview: results[0].status === 'fulfilled' ? results[0].value : [],
    campaigns: results[1].status === 'fulfilled' ? results[1].value : [],
    conversions: results[2].status === 'fulfilled' ? results[2].value : [],
    device: results[3].status === 'fulfilled' ? results[3].value : [],
    assets: results[4].status === 'fulfilled' ? results[4].value : [],
    negatives: results[5].status === 'fulfilled' ? results[5].value : [],
  };
}

function formatData(d) {
  let out = '';

  if (d.overview.length) {
    const o = d.overview[0].metrics;
    out += `OVERVIEW:\nImpressions: ${parseInt(o.impressions||0)} | Clicks: ${parseInt(o.clicks||0)} | Conversions: ${parseFloat(o.conversions||0)} | ConvValue: ${parseFloat(o.conversionsValue||0)} | Spend: ${parseInt(o.costMicros||0)/1000000}\n\n`;
  }

  out += `CAMPAIGNS (${d.campaigns.length}):\n`;
  for (const c of d.campaigns) {
    const cm = c.campaign || {};
    const m = c.metrics || {};
    const spend = parseInt(m.costMicros||0)/1000000;
    const rev = parseFloat(m.conversionsValue||0);
    const roas = spend > 0 ? (rev/spend) : 0;
    out += `${cm.name||'?'} | ${cm.campaignType||'?'} | ${cm.biddingStrategyType||'?'} | ${cm.status||'?'}\n`;
    out += `  Budget:${cm.dailyBudgetMicros?parseInt(cm.dailyBudgetMicros)/1000000:'?'} | Spend:${spend.toFixed(2)} | Clicks:${parseInt(m.clicks||0)} | CTR:${parseFloat(m.ctr||0)>0?(parseFloat(m.ctr)*100).toFixed(2)+'%':'?'} | Convs:${parseFloat(m.conversions||0)} | Rev:${rev.toFixed(2)} | ROAS:${roas.toFixed(2)}x\n`;
    if (cm.targetRoas) out += `  Target ROAS: ${(cm.targetRoas/1000).toFixed(1)}x\n`;
  }

  out += `\nCONVERSIONS (${d.conversions.length}):\n`;
  for (const c of d.conversions) {
    const ca = c.conversionAction || {};
    out += `${ca.name||'?'} | ${ca.type||'?'} | ${ca.conversionActionStatus||'?'} | Attr:${ca.attributionModelType||'?'} | Counting:${ca.countingType||'?'}\n`;
  }

  out += `\nDEVICE:\n`;
  for (const v of d.device) {
    const m = v.metrics || {};
    const spend = parseInt(m.costMicros||0)/1000000;
    const rev = parseFloat(m.conversionsValue||0);
    out += `${v.segments?.device||'?'} | Spend:${spend.toFixed(2)} | Clicks:${parseInt(m.clicks||0)} | Convs:${parseFloat(m.conversions||0)} | ROAS:${spend>0?(rev/spend).toFixed(2)+'x':'?'}\n`;
  }

  out += `\nASSETS (${d.assets.length}):\n`;
  for (const a of d.assets) {
    const ag = a.assetGroup || {};
    const m = a.metrics || {};
    const spend = parseInt(m.costMicros||0)/1000000;
    out += `${ag.name||'?'} | Strength:${ag.adStrength||'?'} | Status:${ag.status||'?'} | Spend:${spend.toFixed(2)} | Convs:${parseFloat(m.conversions||0)}\n`;
  }

  out += `\nNEGATIVES (${d.negatives.length}):\n`;
  for (const n of d.negatives.slice(0,30)) {
    out += `${n.campaignNegative?.keyword?.text||'?'} (${n.campaignNegative?.keyword?.matchType||'?'})\n`;
  }

  return out;
}

async function callLLM(prompt, accountName, accountId, dateRange, fmtData, channel, category) {
  if (!CONFIG.llm_api_key) return null;

  const expertise = {
    'Ad Copy': 'ad copy and creative strategy',
    'Analysis': 'performance analysis and optimization',
    'Audits': 'comprehensive account audits',
    'Tracking': 'conversion tracking and attribution',
    'PMax': 'Performance Max campaigns',
    'Optimise': 'campaign optimization',
    'Feed Management': 'product feed management',
    'CRM Integration': 'CRM integration and offline conversions',
    'Reporting': 'performance reporting',
    'Staff Dashboards': 'team performance dashboards',
  };

  const cleanCat = category.replace(/[^\w\s]/g,'').trim();
  const domain = expertise[cleanCat] || expertise['Analysis'];

  const sys = `You are an advanced digital marketing expert specializing in ${domain}.

Follow these rules:
- Be SPECIFIC with exact numbers from the data
- Cross-reference findings across campaigns
- Calculate derived metrics: ROAS, CPA, CTR, CVR, efficiency
- Flag anomalies: duplicate tracking, budget issues, underperforming segments
- Every recommendation states WHAT to do, WHERE to do it, and WHY
- Use tables for comparisons
- Professional, direct tone - no fluff
- Prioritize recommendations: 🔴 High / 🟡 Medium / 🟢 Low
- End with top 3-4 actions that would most impact performance`;

  const usr = (prompt || 'Comprehensive ' + (category||'performance') + ' analysis') + `

Account: ${accountName} (${accountId})
Channel: ${channel}
Category: ${category}
Date range: ${dateRange}

DATA:
${fmtData}`;

  const body = JSON.stringify({
    systemInstruction: { role: 'user', parts: [{ text: sys }] },
    contents: [{ role: 'user', parts: [{ text: usr }] }],
    generationConfig: { temperature: 0.1, maxOutputTokens: 16000 }
  });

  const url = `${CONFIG.llm_api_url}?key=${CONFIG.llm_api_key}`;
  const res = await httpsPost(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
  }, body);

  if (res.error || res.status !== 200) return null;
  return res.data?.candidates?.[0]?.content?.parts?.[0]?.text;
}

function basicReport(p, name, id, dr, d) {
  let r = `# Report: ${name}\n\n**Account:** ${id} | **Period:** ${dr}\n\n`;
  r += `## Campaigns\n\n| Campaign | Type | Spend | Clicks | Convs | ROAS |\n|----------|------|-------|--------|-------|------|\n`;
  for (const c of d.campaigns||[]) {
    const cm = c.campaign||{}; const m = c.metrics||{};
    const sp = parseInt(m.costMicros||0)/1000000; const rv = parseFloat(m.conversionsValue||0);
    r += `| ${cm.name||'?'} | ${cm.campaignType||'?'} | ${sp.toFixed(2)} | ${parseInt(m.clicks||0)} | ${parseFloat(m.conversions||0)} | ${(sp>0?(rv/sp).toFixed(2):'0')}x |\n`;
  }
  r += `\n*Generated: ${new Date().toISOString().split('T')[0]}*\n`;
  return r;
}

exports.handler = async (event) => {
  const hdrs = { 'Access-Control-Allow-Origin': '*', 'Content-Type': 'application/json', 'Access-Control-Allow-Headers': 'Content-Type' };

  if (event.httpMethod !== 'POST') return { statusCode: 405, headers: hdrs, body: JSON.stringify({ error: 'Method not allowed' }) };

  try {
    const { prompt, promptName, account, accountId, dateRange, days, channel, category } = JSON.parse(event.body || '{}');
    if (!accountId) return { statusCode: 400, headers: hdrs, body: JSON.stringify({ error: 'Missing accountId' }) };

    console.log('run-prompt-v2: accountId=' + accountId + ' days=' + days);

    const token = await getAccessToken();
    const d = parseInt(days) || 7;
    const data = await fetchData(accountId, token, d);

    console.log('Fetched: campaigns=' + data.campaigns.length + ' conversions=' + data.conversions.length + ' assets=' + data.assets.length);

    const fmt = formatData(data);
    let report = await callLLM(prompt, account, accountId, dateRange, fmt, channel||'Google Ads', category||'');

    if (!report) report = basicReport(prompt, account, accountId, dateRange, data);

    return {
      statusCode: 200,
      headers: hdrs,
      body: JSON.stringify({
        ok: true,
        prompt: promptName,
        account, accountId, dateRange,
        report,
        dataPoints: {
          campaigns: data.campaigns.length,
          conversions: data.conversions.length,
          assets: data.assets.length,
          negatives: data.negatives.length,
        },
        generated: new Date().toISOString(),
      }),
    };
  } catch (err) {
    console.error('Error:', err.message);
    return { statusCode: 500, headers: hdrs, body: JSON.stringify({ error: 'Failed', detail: err.message }) };
  }
};