// netlify/functions/test-env.js
// Debug: check what env vars are actually available
exports.handler = async (event) => {
  return {
    statusCode: 200,
    headers: {
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': '*',
    },
    body: JSON.stringify({
      env: {
        GADS_CLIENT_ID: process.env.GADS_CLIENT_ID ? 'SET (' + process.env.GADS_CLIENT_ID.substring(0, 10) + '...)' : 'NOT SET',
        GADS_CLIENT_SECRET: process.env.GADS_CLIENT_SECRET ? 'SET' : 'NOT SET',
        GADS_REFRESH_TOKEN: process.env.GADS_REFRESH_TOKEN ? 'SET' : 'NOT SET',
        GADS_DEV_TOKEN: process.env.GADS_DEV_TOKEN ? 'SET (' + process.env.GADS_DEV_TOKEN.substring(0, 5) + '...)' : 'NOT SET',
        LLM_API_KEY: process.env.LLM_API_KEY ? 'SET (' + process.env.LLM_API_KEY.substring(0, 10) + '...)' : 'NOT SET',
        GOOGLE_CLIENT_ID: process.env.GOOGLE_CLIENT_ID ? 'SET' : 'NOT SET',
        GOOGLE_CLIENT_SECRET: process.env.GOOGLE_CLIENT_SECRET ? 'SET' : 'NOT SET',
      },
    }),
  };
};